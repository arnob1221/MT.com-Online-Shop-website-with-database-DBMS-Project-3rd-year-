<?php
// ✅ session_start() MUST be first — before any header() or output
session_start();

require_once '../config/db.php';
setHeaders(); // sets Content-Type + CORS headers
$input = json_decode(file_get_contents('php://input'), true);

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    if (($input['password'] ?? '') === 'admin') {
        $_SESSION['is_admin'] = true; // ✅ sets PHP session so products.php allows POST/PUT/DELETE
        echo json_encode(['success' => true]);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Wrong password']);
    }
}

elseif ($method === 'DELETE') {
    // Logout — destroy session
    session_destroy();
    echo json_encode(['success' => true]);
}