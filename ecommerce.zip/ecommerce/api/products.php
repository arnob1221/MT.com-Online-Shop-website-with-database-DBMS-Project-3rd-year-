<?php
// ✅ session_start() MUST be first — before setHeaders() which calls header()
session_start();

require_once '../config/db.php';
setHeaders();

$db = getDB();

$method = $_SERVER['REQUEST_METHOD'];

// JSON input
$input = json_decode(file_get_contents('php://input'), true);
if (!$input) {
    $input = $_POST;
}

// ── GET ─────────────────────────
if ($method === 'GET') {

    $id  = isset($_GET['id']) ? (int)$_GET['id'] : null;
    $cat = isset($_GET['cat']) ? (int)$_GET['cat'] : null;

    if ($id) {
        $stmt = $db->prepare("
            SELECT p.*, c.name AS category_name
            FROM products p
            JOIN categories c USING(category_id)
            WHERE p.product_id=?
        ");
        $stmt->bind_param('i', $id);
        $stmt->execute();

        echo json_encode($stmt->get_result()->fetch_assoc() ?: ['error'=>'Not found']);
    }

    elseif ($cat) {
        $stmt = $db->prepare("
            SELECT p.*, c.name AS category_name
            FROM products p
            JOIN categories c USING(category_id)
            WHERE p.category_id=?
        ");
        $stmt->bind_param('i', $cat);
        $stmt->execute();

        echo json_encode($stmt->get_result()->fetch_all(MYSQLI_ASSOC));
    }

    else {
        $res = $db->query("
            SELECT p.*, c.name AS category_name
            FROM products p
            JOIN categories c USING(category_id)
            ORDER BY p.created_at DESC
        ");

        echo json_encode($res->fetch_all(MYSQLI_ASSOC));
    }
}

// ── POST (ADD PRODUCT) ───────────
elseif ($method === 'POST') {

    // 🔐 ADMIN CHECK
    if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
        http_response_code(403);
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    // validation
    if (
        !isset($input['category_id']) ||
        empty($input['name']) ||
        !isset($input['price']) ||
        !isset($input['stock'])
    ) {
        http_response_code(400);
        echo json_encode(['error' => 'All required fields must be filled']);
        exit;
    }

    $stmt = $db->prepare("
        INSERT INTO products (category_id, name, description, price, stock, image_url)
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $category_id = (int)$input['category_id'];
    $name        = $input['name'];
    $desc        = $input['description'] ?? '';
    $price       = (float)$input['price'];
    $stock       = (int)$input['stock'];
    $img         = $input['image_url'] ?? '';

    $stmt->bind_param('issdis',
        $category_id,
        $name,
        $desc,
        $price,
        $stock,
        $img
    );

    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'product_id' => $db->insert_id,
            'message' => 'Product added successfully'
        ]);
    } else {
        http_response_code(500);
        echo json_encode([
            'error' => $stmt->error
        ]);
    }
}

// ── PUT ─────────────────────────
elseif ($method === 'PUT') {

    // 🔐 ADMIN ONLY
    if (!isset($_SESSION['is_admin'])) {
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    $id = $_GET['id'] ?? null;

    if (!$id) {
        echo json_encode(['error'=>'ID required']);
        exit;
    }

    $stmt = $db->prepare("
        UPDATE products
        SET category_id=?, name=?, description=?, price=?, stock=?, image_url=?
        WHERE product_id=?
    ");

    $stmt->bind_param('issdisi',
        $input['category_id'],
        $input['name'],
        $input['description'] ?? '',
        $input['price'],
        $input['stock'],
        $input['image_url'] ?? '',
        $id
    );

    $stmt->execute();

    echo json_encode(['success'=>true]);
}

// ── DELETE ───────────────────────
elseif ($method === 'DELETE') {

    // 🔐 ADMIN ONLY
    if (!isset($_SESSION['is_admin'])) {
        echo json_encode(['error' => 'Unauthorized']);
        exit;
    }

    $id = $_GET['id'] ?? null;

    if (!$id) {
        echo json_encode(['error'=>'ID required']);
        exit;
    }

    $stmt = $db->prepare("DELETE FROM products WHERE product_id=?");
    $stmt->bind_param('i', $id);
    $stmt->execute();

    echo json_encode(['success'=>true]);
}

$db->close();