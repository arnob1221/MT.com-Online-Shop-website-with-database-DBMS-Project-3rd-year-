<?php
require_once '../config/db.php';
setHeaders();

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$input = json_decode(file_get_contents('php://input'), true);

if ($method === 'GET') {
    // ✅ FIX Bug #5: GET handler was missing — admin dashboard needs this
    $res = $db->query("
        SELECT o.*, c.name AS customer_name
        FROM orders o
        JOIN customers c USING(customer_id)
        ORDER BY o.created_at DESC
    ");
    echo json_encode($res->fetch_all(MYSQLI_ASSOC));
}

elseif ($method === 'PUT') {
    // Update order status
    $id = $_GET['id'] ?? null;
    if (!$id || empty($input['status'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Order ID and status required']);
        exit;
    }
    $stmt = $db->prepare("UPDATE orders SET status=? WHERE order_id=?");
    $stmt->bind_param('si', $input['status'], $id);
    $stmt->execute();
    echo json_encode(['success' => true]);
}

elseif ($method === 'POST') {
    if (empty($input['customer_id']) || empty($input['items'])) {
        http_response_code(400);
        echo json_encode(['error'=>'Invalid data']);
        exit;
    }

    $db->begin_transaction();

    try {
        $total = 0;
        $items = [];

        foreach ($input['items'] as $item) {
            $pid = (int)$item['product_id'];
            $qty = (int)$item['quantity'];

            if ($qty <= 0) throw new Exception("Invalid quantity");

            $stmt = $db->prepare("SELECT price, stock FROM products WHERE product_id=?");
            $stmt->bind_param('i', $pid);
            $stmt->execute();

            $p = $stmt->get_result()->fetch_assoc();

            if (!$p || $p['stock'] < $qty) {
                throw new Exception("Stock problem");
            }

            $total += $p['price'] * $qty;

            $items[] = [
                'pid'=>$pid,
                'qty'=>$qty,
                'price'=>$p['price']
            ];
        }

        $stmt = $db->prepare("INSERT INTO orders (customer_id,total_amount) VALUES (?,?)");
        $stmt->bind_param('id', $input['customer_id'], $total);
        $stmt->execute();

        $oid = $db->insert_id;

        foreach ($items as $it) {
            $stmt = $db->prepare("
                INSERT INTO order_items (order_id, product_id, quantity, unit_price)
                VALUES (?, ?, ?, ?)
            ");
            $stmt->bind_param('iiid', $oid, $it['pid'], $it['qty'], $it['price']);
            $stmt->execute();

            $stmt = $db->prepare("
                UPDATE products SET stock = stock - ?
                WHERE product_id=? AND stock >= ?
            ");
            $stmt->bind_param('iii', $it['qty'], $it['pid'], $it['qty']);
            $stmt->execute();
        }

        $db->commit();

        echo json_encode(['success'=>true,'order_id'=>$oid,'total'=>$total]);

    } catch (Exception $e) {
        $db->rollback();
        echo json_encode(['error'=>$e->getMessage()]);
    }
}

$db->close();
